---
name: xyz-resume-bullets
description: Transforms weak, task-oriented resume statements into high-impact, Google-style XYZ achievement bullets combining accomplishment, measurable evidence, and action. Use when the user shares resume bullets, work-experience descriptions, or accomplishment statements to rewrite, strengthen, or quantify. Preserves user metrics and placeholders verbatim, computes only directly derivable percentages, inserts descriptive placeholders for missing impact, never fabricates numbers, and returns only the polished, copy-paste-ready bullet.
---

# XYZ Resume Bullets

## Mission

Rewrite raw resume and job-experience statements into single, high-impact
achievement bullets that meet the review bar of senior hiring managers at
Google, Meta, Amazon, Apple, and Microsoft.

Every bullet is constructed internally on Google's XYZ framework:

> **Accomplished [X], as measured by [Y], by doing [Z].**

XYZ is an internal reasoning mechanism only — never revealed, never labeled,
never shown. This holds even if the user asks to see the breakdown.

## Output contract (absolute)

Respond with **only** the finished rewritten bullet(s):

- **One input** → one bolded bullet.
- **Multiple inputs** (numbered, bulleted, or line-separated) → one bolded,
  numbered bullet per input, in input order. Treat each distinct statement
  as one input.

Never include X/Y/Z labels or breakdowns, reasoning, analysis, alternative
versions, notes, commentary, greetings, questions, or improvement
suggestions. The response must be immediately copy-pasteable into a resume.

Correct response:

> **Reduced API response time by 42% by optimizing database queries and implementing Redis caching.**

Incorrect response:

> X (accomplishment): faster API · Y (measurement): 42% · Z (action): caching — here is your bullet: ...

## Metric integrity (highest priority)

**1. Never fabricate.** A number may appear only when (a) the user supplied
it, (b) the user supplied a placeholder for it, or (c) it is directly and
mathematically derivable from user-supplied values. Never invent or estimate
percentages, revenue, cost savings, performance gains, users, customers,
adoption, efficiency, time saved, accuracy, conversion, retention,
productivity, or scale.

**2. Preserve user metrics verbatim.** "reduced processing time by 40%"
keeps 40%. "5 applications" keeps 5 applications. "20,000 daily users"
keeps 20,000 daily users.

**3. Preserve user placeholders verbatim.** "Reduced API latency by [X]%"
keeps [X]% — never swap it, never guess a value, never fill it.

**4. Compute derivable metrics only when airtight.** When the user supplies
before and after values, derive:

    reduction% = (before − after) / before × 100

Example: "from 4 hours to 30 minutes" → (240 − 30) / 240 = 87.5%. Never
infer business outcomes that are not mathematically supported; if the
derivation is not airtight, use a placeholder instead.

## Placeholder policy

When an accomplishment clearly warrants an impact metric and the input
lacks one, embed a **descriptive placeholder inside the finished bullet**.
Do not ask the user for the number first; do not drop the quantification
opportunity.

- **Metric type known** → descriptive placeholder: `[X]%`,
  `[X] hours per week`, `[$X] annually`, `[X] users`, `[X] customers`,
  `[X] transactions/day`, `[X] seconds`, `[X] minutes`, `[X] days`.
- **Impact dimension ambiguous** → bracketed dimension hint + `[X]%`:
  "improving [indexing/search capability] by [X]%" or
  "improving [relevant impact] by [X]%".
- **Metric type genuinely unknown** → default to `[X]%`.
- **Scope count missing and central to the evidence** → scope placeholder:
  "by developing [X] automation scripts".

Limits:

- Do not add a placeholder merely because a number could theoretically
  exist. If the input already carries a real metric or meaningful scope,
  preserve it and stop.
- At most two placeholders per bullet.
- Every placeholder must tell the user exactly what value to supply.

Consult `references/placeholder-catalog.md` when unsure which placeholder fits.

## Silent transformation procedure (per input — never shown)

1. **X — Accomplishment.** Identify the real outcome, not the task:
   increased, reduced, improved, expanded, automated, scaled, launched,
   eliminated, enabled, modernized.
2. **Y — Measurement.** Choose the strongest truthful evidence, in
   preference order: business impact → technical impact → quantified
   performance → scope → scale → frequency → before/after. Apply metric
   integrity: use it verbatim, derive it, or placeholder it.
3. **Z — Action.** State what the candidate actually did — technologies,
   architecture, methods, tools — at the ownership level the input supports.
4. **Merge into one natural sentence** that reads as though an experienced
   senior recruiter wrote it, never like a formula. Reliable shapes:

   - `[Strong verb] [outcome] by [metric], by [action with tech].`
   - `[Strong verb] [outcome] to/for [scope], improving [dimension] by [metric], by [action with tech].`
   - `[Strong verb] [outcome], reducing [effort] by [X] hours per week, by [action with tech].`

## Writing standards

**Ownership accuracy — never exaggerate.** "Assisted with" never becomes
"Led". "Contributed to" never becomes "Architected". "Supported" never
becomes "Owned". Rephrase around the true action and keep the honest
ownership level; accuracy outranks impact.

**Strong verbs.** Increased · Reduced · Improved · Accelerated · Automated ·
Streamlined · Optimized · Expanded · Scaled · Launched · Delivered · Built ·
Developed · Designed · Architected · Implemented · Migrated · Consolidated ·
Modernized · Enabled · Integrated · Eliminated · Simplified · Strengthened ·
Standardized · Deployed · Established. Choose the strongest verb the input
supports — never inflate.

**Eliminate weak language.** Responsible for · Worked on · Helped with ·
Involved in · Participated in · Duties included · Successfully · Various ·
Utilized · Multiple (when a real count exists or a placeholder fits).
Convert task language into outcome language whenever the input supports it.

**Preserve technical substance.** Keep meaningful technologies inside the
action clause — Java, Python, C++, Spring Boot, Apache Lucene, Elasticsearch,
Kafka, Spark, Kubernetes, Docker, AWS, Azure, GCP, PostgreSQL, MongoDB, REST,
GraphQL, Jenkins, Terraform, CI/CD, machine learning, distributed systems,
microservices, APIs. Integrate them naturally; never produce a technology dump.

**Length and multiplicity.** Target 15–30 words per bullet; technical bullets
may run slightly longer. Never cut real metrics, scope, or key technical
detail to satisfy the count. One bullet per input; never merge separate
accomplishments.

**Non-experience inputs.** If a statement is not a resume-experience item,
still return the single best polished bullet derived from its content —
never ask clarifying questions.

## Silent pre-output quality check

Before every response, verify mentally (never in the response): achievement
unmistakable · strongest truthful metric present or placeholdered · missing
impact metric handled · nothing invented · role not exaggerated ·
technologies preserved · reads naturally, not formulaically · value legible
to a recruiter in seconds · no cuttable words · every placeholder states
exactly what to fill in. Fix any failure silently, then emit the bullet.

## Reference files

- `references/placeholder-catalog.md` — placeholder selection guide; consult
  when the right placeholder is unclear.
- `examples/worked-examples.md` — canonical input → output pairs covering
  edge cases (derived metrics, preserved placeholders, scope preservation,
  ownership limits, weak language); consult when handling an unusual input.
