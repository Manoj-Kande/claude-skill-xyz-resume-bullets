# Worked Examples

Canonical input → output pairs. Each Output is the complete skill response
for that Input — bullet only, no commentary.

## 1. Real percentage present — preserve, no placeholder

Input: Managed social media accounts and increased page views by 23% over six
months by launching a social distribution strategy.

Output:
**Increased page views by 23% over six months by launching a social distribution strategy across social media channels.**

## 2. Scope number present + impact missing — preserve scope, placeholder impact

Input: Extended an Apache Lucene-based enterprise search feature to related
formats — enhancing XML and JSON parsing pipelines with custom data models for
structured extraction, enabling indexing across 2 additional document modules.

Output:
**Extended Apache Lucene-based enterprise search to 2 additional document modules, improving [indexing/search capability] by [X]%, by building custom XML/JSON parsing pipelines with custom data models for structured extraction.**

## 3. No metric at all — placeholder, never invent

Input: Improved application performance through database optimization.

Output:
**Improved application performance by [X]% by optimizing database queries, indexing, and database access patterns.**

Input: Automated a manual reporting workflow using Python.

Output:
**Automated the manual reporting workflow, reducing reporting effort by [X] hours per week by developing a Python-based automation pipeline.**

Input: Built automation scripts for regression testing.

Output:
**Automated regression testing, reducing manual testing effort by [X]%, by developing [X] automation scripts.**

## 4. User placeholder supplied — preserve verbatim

Input: Reduced API latency by [X]% using Redis caching.

Output:
**Reduced API latency by [X]% by implementing Redis caching.**

## 5. Mathematically derivable — compute exactly

Input: Reduced processing time from 4 hours to 30 minutes.

Output:
**Reduced processing time by 87.5% by optimizing the processing workflow.**

((240 − 30) / 240 = 87.5%. Compute only when both values are user-supplied.)

## 6. Full evidence present — no placeholders

Input: Built 3 automation scripts that saved 12 hours of manual testing each week.

Output:
**Reduced manual regression-testing effort by 12 hours per week by developing 3 automation scripts.**

Input: Redesigned Kafka-based ingestion pipelines and optimized Spark workloads,
scaling data processing to 5M daily records.

Output:
**Scaled data processing to 5M daily records by redesigning Kafka-based ingestion pipelines and optimizing Spark workloads.**

## 7. Multiple inputs — one numbered bullet each

Input:
1. Built REST APIs using Java.
2. Improved database performance.
3. Migrated services to AWS.

Output:
**1. Developed REST APIs in Java supporting [X] requests/day.**

**2. Improved database performance by [X]% by optimizing queries, indexing, and access patterns.**

**3. Migrated [X] services to AWS, reducing infrastructure costs by [X]%.**

## 8. Ownership must not be inflated

Input: Assisted with migrating 6 monolithic services to microservices on
Kubernetes.

Output:
**Assisted in migrating 6 monolithic services to Kubernetes-based microservices, improving [scalability/deployment speed] by [X]%.**

## 9. Weak task language → outcome language

Input: Responsible for maintaining Java backend services for order processing.

Output:
**Maintained Java backend services for order processing, supporting [X] orders/day.**
