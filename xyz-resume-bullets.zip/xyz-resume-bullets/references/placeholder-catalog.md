# Placeholder Catalog

Consulted when a missing impact metric requires a placeholder. Objective:
the user must know exactly what value to supply, and no number is ever invented.

## Patterns, most specific → most generic

### Named dimension + `[X]%`
The input reveals what improved but not by how much.
- "reducing API latency by [X]%"
- "reducing deployment time by [X]%"
- "improving application performance by [X]%"
- "increasing test coverage by [X]%"

### Bracketed dimension hint + `[X]%`
Impact clearly exists but the dimension is ambiguous; suggest the likeliest
1–2 dimensions for the user to choose or replace.
- "improving [indexing/search capability] by [X]%"
- "improving [scalability/reliability] by [X]%"
- "improving [relevant impact] by [X]%" (most generic hint)

### Effort / time saved
- "[X] hours per week" · "[X] hours per month" · "[X] minutes per day"
- "Automated the manual reporting workflow, reducing reporting effort by
  [X] hours per week by developing a Python-based automation pipeline."

### Money
- "[$X]" · "[$X] annually" · "[$X] per quarter"
- "reducing infrastructure spend by [$X] annually"

### People / adoption
- "[X] users" · "[X] customers" · "[X] stakeholders" · "[X] teams"

### Volume / throughput
- "[X] transactions/day" · "[X] requests/second" · "[X] records/day" ·
  "[X] documents indexed/day"

### Duration
- "[X] seconds" · "[X] minutes" · "[X] days" · "[X] weeks"

### Scope counts — only when the count is itself central evidence
- "[X] services" · "[X] applications" · "[X] microservices" ·
  "[X] automation scripts" · "[X] dashboards" · "[X] data pipelines"
- "Automated regression testing, reducing manual testing effort by [X]%, by
  developing [X] automation scripts."

### Fallback
- `[X]%` — use when the metric type is genuinely unknown; never invent a
  more specific category just to look decisive.

## Hard rules

1. Never fill, guess, or estimate a placeholder value.
2. Never replace or reformat a user-supplied placeholder.
3. At most two placeholders per bullet — typically one impact placeholder,
   plus a scope placeholder only when the count is genuinely evidentiary.
4. Prefer the most specific pattern the input supports; degrade toward
   `[X]%` only when nothing more specific is defensible.
5. The placeholder's unit must match how that metric would actually be
   measured for that accomplishment.
